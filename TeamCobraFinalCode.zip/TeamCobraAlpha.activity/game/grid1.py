import pygame
import spyral 



WIDTH = 1000
HEIGHT = 900

pygame.display.set_caption("Battleship")


COORD_WIDTH = WIDTH * .5
COORD_HEIGHT = HEIGHT * .5
PAD_LEFT = (WIDTH - COORD_WIDTH) * .3
PAD_RIGHT = WIDTH - COORD_WIDTH - PAD_LEFT
PAD_TOP = (HEIGHT - COORD_HEIGHT) * .3
PAD_BOTTOM = HEIGHT - COORD_HEIGHT - PAD_TOP
NUM_X_POINTS = 10.0
NUM_Y_POINTS = 10.0
FONT_SIZE = 37
# Define some colors
black    = (   0,   0,   0)
white    = ( 255, 255, 255)
green    = (   0, 255,   0)
red      = ( 255,   0,   0)
 
size=[255,255]
screen=pygame.display.set_mode(size)
 
pygame.display.set_caption("Battleship")
 
margin=5
 
grid=[]
for row in range(10):
    grid.append([])
    for column in range(10):
        grid[row].append(0)
 
grid[1][5] = 1
grid[1][6] = 1
grid[1][7] = 1
grid [1][8] = 1

grid[3][2] = 1
grid[3][3] = 1
grid[3][4] = 1
grid[3][5] = 1
grid[3][6] = 1

grid[3][8] = 1
grid[4][8] = 1


class Ship(spyral.Sprite):
    ''' create battleships in random places '''

    def __init__(self, scene, coord):
        super(Hoop, self).__init__()
        self.scene = scene

        self.is_target = False


        

        self.x_coord = coord[0]
        self.y_coord = coord[1]

        self.x = (self.x_coord/ NUM_X_POINTS * COORD_WIDTH + PAD_LEFT)
        self.y = HEIGHT - ((self.y_coord / NUM_Y_POINTS) * COORD_HEIGHT) - PAD_BOTTOM


       
    def update(self, dt):
        

        if (self.curr_x_input != self.scene.x_input or
                                    self.curr_y_input != self.scene.y_input):
            self.curr_x_input = self.scene.x_input
            self.curr_y_input = self.scene.y_input
            self.redraw_all_pieces()
            return


    def get_input(self, posn):
        print posn[0], posn[1]
        if self.x_input_rect.collide_point(posn):
            # user clicked inside of x input box
            self.highlighted_coord = "x"
            self.scene.x_input = ""
        if self.y_input_rect.collide_point(posn):
            # user clicked inside of y input box
            self.highlighted_coord = "y"
            self.scene.y_input = ""
        if self.submit_input_rect.collide_point(posn):
            if self.scene.x_input == "" or self.scene.y_input == "":
                return
            self.scene.waiting_for_input = False


    def type_key(self, key):
        if key in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']:
            # user entered an int
            if key == "\b":
                # enter has been pressed
                return
            if self.highlighted_coord == "x":
                self.scene.x_input += key
            elif self.highlighted_coord == "y":
                self.scene.y_input += key



        


    def reset(self):
        for ship in self.ship:
            self.group.remove(ship)

        self.user_has_shot = True

        self.hoops = get_hoops(self)
        for hoop in self.hoops:
            self.group.add(hoop)

        self.up_ball.pos = (COORD_WIDTH/2 + PAD_LEFT, HEIGHT)
        self.down_ball.pos = (WIDTH/2, -self.down_ball.image._surf.get_height())
        self.up_ball.vel_y = 0
        self.down_ball.vel_y = 0

        self.x_input = ""
        self.y_input = ""

        self.run_num = 1

        self.waiting_for_input = True


    

        
    def render(self):
        # Simply tell the group to draw
        self.group.draw()


    class Scoreboard(spyral.Sprite):
    def __init__(self, scene):
        super(Scoreboard, self).__init__()
        self.scene = scene

        self.curr_score = 0
        self.curr_shots = 0

        self.curr_x_input = ""
        self.curr_y_input = ""

        self.score_posn = (1000, 100)

        self.inputs_text_posn = (1000, self.score_posn[1] + FONT_SIZE)

        self.x_input_posn = (self.inputs_text_posn[0] + 10, self.score_posn[1] + FONT_SIZE) 
        self.y_input_posn = (self.inputs_text_posn[0] + 68, self.score_posn[1] + FONT_SIZE) 

        self.submit_text_posn = (1000, self.y_input_posn[1] + FONT_SIZE) 
        self.submit_input_posn = (1000 + 15, self.y_input_posn[1] + FONT_SIZE)

        self.input_rect_size = (45, 30) 
        self.submit_rect_size = (95, 30) 

        self.x_input_rect = spyral.Rect(self.x_input_posn, self.input_rect_size)
        self.y_input_rect = spyral.Rect(self.y_input_posn, self.input_rect_size)
        self.submit_input_rect = spyral.Rect(self.submit_input_posn, self.submit_rect_size)

        self.highlighted_coord = "x"

        self.redraw_all_pieces()
    


    

    def update(self, dt):
        if (self.curr_x_input != self.scene.x_input or
                                    self.curr_y_input != self.scene.y_input):
            self.curr_x_input = self.scene.x_input
            self.curr_y_input = self.scene.y_input
            self.redraw_all_pieces()
            return
        
        self.group.update(dt)
        while done==False:
    for event in pygame.event.get(): 
        if event.type == pygame.QUIT: 
            done=True
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            column=pos[0] // (width+margin)
            row=pos[1] // (height+margin)
            grid[row][column] = 2
            
        

                  
 

 

 
 
while done==False:
    for event in pygame.event.get(): 
        if event.type == pygame.QUIT: 
            done=True
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            column=pos[0] // (width+margin)
            row=pos[1] // (height+margin)
            grid[row][column] = 2
        if grid[row][column] == 1 & event.type == pygame.MOUSEBUTTONDOWN:
                
                pos = pygame.mouse.get_pos()
                column=pos[0] // (width+margin)
                row=pos[1] // (height+margin)
                grid[row][column] = 3
        
 
    screen.fill(black)
 
    for row in range(10):
        for column in range(10):
            color = white
            if grid[row][column] == 1:
                color = green
            pygame.draw.rect(screen,color,[(margin+width)*column+margin,(margin+height)*row+margin,width,height])

            if grid[row][column] == 2:
                color = red
            pygame.draw.rect(screen,color,[(margin+width)*column+margin,(margin+height)*row+margin,width,height])

            if grid[row][column] == 3:
                color = blue
            pygame.draw.rect(screen,color,[(margin+width)*column+margin,(margin+height)*row+margin,width,height])
     
    
 
    pygame.display.flip()
     
pygame.quit ()
