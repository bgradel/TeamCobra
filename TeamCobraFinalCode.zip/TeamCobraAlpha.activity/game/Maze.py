import spyral
import random
import math
import Menu
import pacmath
import battleship
import Shopping
import instructions

WIDTH = 1200
HEIGHT = 900
PADDING = 75
LISTOFBLOCKS = []
PATH = []
ADDPATH = []
MINIGAMES = ['Battleship', 'PacMath', 'Shopping']#, 'Battleship', 'Shopping']
BOARDAVAILABILITY = []
SCORE = 0
CURRENTGAME = ''	


class Score(spyral.Sprite):
    #---------------THE SCORE CLASS ---------------#
	# The score class consists of a sprite that    #
	# displays the score to the player in the      #
	# bottom-left hand corner of the screen.       #
	#----------------------------------------------#
    def __init__(self, newX, newY):
        super(Score, self).__init__()
        font = spyral.Font(None, 64, (255, 255, 255))
        scoreText = spyral.Image(size=(100, 100))
        scoreText = font.render('Score: ' + unicode(SCORE))
        self.image = scoreText
        self.anchor = 'midleft'
        self.x = 200
        self.y = 825

class Character(spyral.Sprite):
    #---------------THE CHARACTER CLASS ---------------#
	# The character class consists of a single         #
	# character sprite that the player controls.  The  #
	# arrow keys are used to navigate through the maze.#
	#--------------------------------------------------#
    def __init__(self, file, newXBlock, newYBlock, newDimension):
        super(Character, self).__init__()
        self.anchor = 'center'
        self.x = PADDING + (newXBlock * newDimension)
        self.y = PADDING + (newYBlock * newDimension)
        self.pos = (self.x, self.y)
        self.image = spyral.Image(filename=file)
        self.visible = True
        self.moving = False
        self.layer = 2
        self.current_xBlock = newXBlock
        self.current_yBlock = newYBlock
        self.moves = 0
        self.moveMax = 10

class Block(spyral.Sprite):
    #-------------------- THE BLOCK CLASS --------------------#
	# The block contains a sprite that holds important pieces #
	# of information needed to construct the maze.  This class#
	# consists of a series of small functions that perform    #
	# minor duties to ensure a valid maze is produced.        #
	#---------------------------------------------------------#
    def __init__(self, newX, newY, newDimension):
        super(Block, self).__init__()
        self.x = newX
        self.y = newY
        self.layer = 1
        self.path = False
        self.actions = ['up', 'down', 'right', 'left']	      
    def turnToStart(self):
        global PATH
        self.path = True
        self.parent = 0
        PATH.append(self)
    def turnToAddStart(self):
        global ADDPATH
        self.path = True
        ADDPATH.append(self)
    def turnToPath(self, block, action):
        global PATH
        self.path = True
        self.parent = block
        self.takenAction = action
        PATH.append(self)
    def turnToAddPath(self, block, action):
        global ADDPATH
        self.path = True
        self.parent = block
        self.takenAction = action
        ADDPATH.append(self)
    #--------------- resultingBlock ---------------#
	# The resultingBlock function returns the block#
	# that results when the current action is      #
	# applied to the current one.                  #
	#----------------------------------------------#
    def resultingBlock(self, x):
        if (x == 'up'):
            return LISTOFBLOCKS[self.y-1][self.x]
        elif (x == 'down'):
            return LISTOFBLOCKS[self.y+1][self.x]
        elif (x == 'left'):
            return LISTOFBLOCKS[self.y][self.x-1]
        else:
            return LISTOFBLOCKS[self.y][self.x+1]
    #--------------- isSurrounded ---------------#
	# The isSurrounded function retuns whether or#
	# not the given block is surrounded by any   #
	# 'wall squares' (a square that is not open).#
	#--------------------------------------------#
    def isSurrounded(self, action):
        global LISTOFBLOCKS
        if (action == 'up'):
            action = 'down'
        elif (action == 'down'):
            action = 'up'
        elif (action == 'right'):
            action = 'left'
        elif (action == 'left'):
            action = 'right'
        if (action in self.actions):
            self.actions.remove(action)
        for x in self.actions:
            if (self.resultingBlock(x).path == True):
                self.actions.append(action)
                return True
            else:
                pass
        self.actions.append(action)
        return False
    #--------------- constructPath ---------------#
	# The constructPath function is responsible   #
	# for creating a path that will be the        #
	# solution to the maze that is created later  #
	# on.                                         #
	#---------------------------------------------#
    def constructPath(self, across, down):
        global PATH
        PATH.append(self)
        actions = ['up', 'down', 'right', 'left']	
        if (self.y == 0):
            actions.remove('up')
        if (self.y == down-1):
            actions.remove('down')
        if (self.x == 0):
            actions.remove('left')
        if (self.x == across-1):
            actions.remove('right')
        toDelete = []
        for x in actions:
            if (self.resultingBlock(x).path == True):
                toDelete.append(x)
            else:
                pass
        for x in toDelete:
            actions.remove(x)
        toDelete2 = []
        for x in actions:
            if (self.resultingBlock(x).isSurrounded(x) == True):
                toDelete2.append(x)
            else:
                pass
        for x in toDelete2:
            actions.remove(x)
        if (len(actions) == 0):
            PATH.pop()
            self.parent.actions.remove(self.takenAction)
        else:
            action = actions[random.randint(0, len(actions)-1)]
            self.resultingBlock(action).turnToPath(self, action)
    #--------------- constructAddPath ---------------#
	# The constructAddPath function is responsible   #
	# for creating multiple 'tributary' paths that   #
	# will not lead to the finish of the maze.       #
	#------------------------------------------------#
    def constructAddPath(self, across, down):
        global ADDPATH
        ADDPATH.append(self)
        actions = ['up', 'down', 'right', 'left']	
        if (self.y == 0):
            actions.remove('up')
        if (self.y == down-1):
            actions.remove('down')
        if (self.x == 0):
            actions.remove('left')
        if (self.x == across-1):
            actions.remove('right')
        toDelete = []
        for x in actions:
            if (self.resultingBlock(x).path == True):
                toDelete.append(x)
            else:
                pass
        for x in toDelete:
            actions.remove(x)
        toDelete2 = []
        for x in actions:
            if (self.resultingBlock(x).isSurrounded(x) == True):
                toDelete2.append(x)
            else:
                pass
        for x in toDelete2:
            actions.remove(x)
        if (len(actions) == 0):
            pass
        else:
            action = actions[random.randint(0, len(actions)-1)]
            self.resultingBlock(action).turnToAddPath(self, action)	
			
class Maze(spyral.Scene):
    #--------------- THE MAZE CLASS ---------------#
    # The maze class actually creates and displays #
    # the maze.  Once this has been done, a score  #
    # and character sprite are each added to the   #
    # scene.                                       #
    #----------------------------------------------#
    def __init__(self, *args, **kwargs):
        super(Maze, self).__init__(*args, **kwargs)
        self.camera = self.parent_camera.make_child(virtual_size = (WIDTH, HEIGHT))
        self.group = spyral.Group(self.camera)
        global PATH, LISTOFBLOCKS, SCORE, PADDING, BOARDAVAILABILITY
        SCORE = 0
        if (Menu.DIFFICULTY == 0):
            difficulty = 'Easy'
            self.dimension = 60
        elif (Menu.DIFFICULTY == 1):
            difficulty = 'Medium'
            self.dimension = 40
        else:
            difficulty = 'Hard'
            self.dimension = 30
        self.set_globals(difficulty)
        for y in xrange(self.blocksDown):
            LISTOFBLOCKS.append([])
        for y in xrange(self.blocksDown):
            for x in xrange(self.blocksAcross):
                newBlock=Block(x,y,self.dimension)
                if (x == 0):			 
                    newBlock.actions.remove('left')
                if (x == self.blocksAcross-1):			 
                    newBlock.actions.remove('right')
                if (y == 0):			 
                    newBlock.actions.remove('up')
                if (y == self.blocksDown-1):			 
                    newBlock.actions.remove('down')
                LISTOFBLOCKS[y].append(newBlock)
        xOfStart = random.randint(0,(self.blocksAcross-1))
        yOfStart = random.randint(0,(self.blocksDown-1))
        LISTOFBLOCKS[yOfStart][xOfStart].turnToStart()
        nextBlock = PATH.pop()
        for x in xrange(100):
            if (len(PATH) < (30 + (10*Menu.DIFFICULTY))):
                nextBlock.constructPath(self.blocksAcross, self.blocksDown)
                nextBlock = PATH.pop()
            else:
                break
        xOfFinish = nextBlock.x
        yOfFinish = nextBlock.y
        for z in range(500):
            x = random.randint(1, len(PATH)-1)
            PATH[x].turnToAddStart()
            nextBlock = ADDPATH.pop()
            for x in xrange(20):
                nextBlock.constructAddPath(self.blocksAcross, self.blocksDown)
                nextBlock = ADDPATH.pop()
            for y in ADDPATH:
                PATH.append(y)
                ADDPATH.remove(y)
        for y in xrange(self.blocksDown):
            BOARDAVAILABILITY.append([])
        for y in xrange(self.blocksDown):
            for x in xrange(self.blocksAcross):
                if (LISTOFBLOCKS[y][x].path == True):
                    BOARDAVAILABILITY[y].append(1)
                else:
                    BOARDAVAILABILITY[y].append(0)
        BOARDAVAILABILITY[yOfFinish][xOfFinish] = 2
        self.character = Character(self.File5, xOfStart, yOfStart, self.dimension)
        self.group.add(self.character)
        self.score = Score(200,825)
        self.group.add(self.score)
    def on_enter(self):
        background = spyral.Image(size=(WIDTH,HEIGHT))
        background.anchor='topleft'
        background.fill((0,0,0))
        for y in xrange(self.blocksDown):
            for x in xrange(self.blocksAcross):
                if (BOARDAVAILABILITY[y][x] == 1):
                    new_block = spyral.Image(filename=self.File1)
                    background.draw_image(new_block, position=(75+(x*self.dimension)-600,75+(y*self.dimension)-450), anchor='center')
                elif (BOARDAVAILABILITY[y][x] == 0):
                    new_block = spyral.Image(filename=self.File2)
                    background.draw_image(new_block, position=(75+(x*self.dimension)-600, 75+(y*self.dimension)-450), anchor='center')
                else:
                    new_block = spyral.Image(filename=self.File3)
                    background.draw_image(new_block, position=(75+(x*self.dimension)-600, 75+(y*self.dimension)-450), anchor='center')
        self.camera.set_background(background)
        font = spyral.Font(None, 64, (255, 255, 255))
        scoreText = spyral.Image(size=(100, 100))
        scoreText = font.render('Score: ' + unicode(SCORE))
        self.score.image = scoreText
    def render(self):
        self.group.draw()
    def update(self, dt):
        """
        The update loop receives dt as a parameter, which is the amount
        of time which has passed since the last time update was called.
        """
        global PATH
        global SCORE
        global BOARDAVAILABILITY
        global CURRENTGAME
        self.group.update(dt)
        for event in self.event_handler.get():
            if event['type'] == 'QUIT':
                self.character.moves = 0
                for i in xrange(self.blocksDown):
                    LISTOFBLOCKS.pop()
                    BOARDAVAILABILITY.pop()
                for i in xrange(len(PATH)):
                    PATH.pop()
                self.group.empty()
                spyral.director.pop()
                return
            if event['type'] == 'KEYDOWN':
                if event['key'] == spyral.keys.up:
                    self.character.moving = 'up'
                    character_image = spyral.Image(filename=self.File4)
                    self.character.image = character_image
                if event['key'] == spyral.keys.down:
                    self.character.moving = 'down'
                    character_image = spyral.Image(filename=self.File5)
                    self.character.image = character_image
                if event['key'] == spyral.keys.left:
                    self.character.moving = 'left'
                    character_image = spyral.Image(filename=self.File6)
                    self.character.image = character_image
                if event['key'] == spyral.keys.right:
                    self.character.moving = 'right'
                    character_image = spyral.Image(filename=self.File7)
                    self.character.image = character_image
            elif event['type'] == 'KEYUP':
                if event['key'] in (spyral.keys.up, spyral.keys.down, spyral.keys.left, spyral.keys.right):
                    self.character.moving = False
		#--------------- valid_move ---------------#
		# The valid_move function tells whether or #
		# not the character is able to make the    #
		# given move from his or her current spot. #
        #------------------------------------------#
        def valid_move(character):
            if (character.moving == 'up' and (character.current_yBlock-1 in xrange(self.blocksDown))):
                return BOARDAVAILABILITY[character.current_yBlock-1][character.current_xBlock] > 0
            elif (character.moving == 'down' and (character.current_yBlock+1 in xrange(self.blocksDown))):
                return BOARDAVAILABILITY[character.current_yBlock+1][character.current_xBlock] > 0
            elif (character.moving == 'left' and (character.current_xBlock-1 in xrange(self.blocksAcross))):
                return BOARDAVAILABILITY[character.current_yBlock][character.current_xBlock-1] > 0
            elif (character.moving == 'right' and (character.current_xBlock+1 in xrange(self.blocksAcross))):
                return BOARDAVAILABILITY[character.current_yBlock][character.current_xBlock+1] > 0
            else:
                return False
		#--------------- move_and_correct ---------------#
		# If the given move is valid, the                #
		# move_and_correct function will change the      #
		# location of the character.                     #
		#------------------------------------------------#
        def move_and_correct(character):
            if (valid_move(character)):
                if (character.moving == 'up'):
                    character.moving = False
                    character.y -= self.dimension
                    character.current_yBlock-=1
                    character.moves+=1
                elif (character.moving == 'down'):
                    character.moving = False
                    character.y += self.dimension
                    character.moves+=1
                    character.current_yBlock+=1
                elif (character.moving == 'left'):
                    character.moving = False
                    character.x -= self.dimension
                    character.moves+=1
                    character.current_xBlock-=1
                elif (character.moving == 'right'):
                    character.moving = False
                    character.x += self.dimension
                    character.moves+=1
                    character.current_xBlock+=1
                else:
                    character.moving = False
            else:
                character.moving = False
            character.pos = (character.x, character.y)
        move_and_correct(self.character)
        if (BOARDAVAILABILITY[self.character.current_yBlock][self.character.current_xBlock] == 2):
            for i in xrange(self.blocksDown):
                LISTOFBLOCKS.pop()
                BOARDAVAILABILITY.pop()
            for i in xrange(len(PATH)):
                PATH.pop()
            self.character.moves = 0
            self.group.empty()
            CURRENTGAME = 'Done'
            spyral.director.replace(instructions.Instructions())
        elif (self.character.moves >= self.character.moveMax):
            self.character.moves = 0
            minigame = random.randint(0, len(MINIGAMES)-1)
            selection = MINIGAMES[minigame]
            CURRENTGAME = selection
            spyral.director.push(instructions.Instructions())

    #--------------- set_globals ---------------#
	# The set_globals function takes the game's #
	# difficulty and appends it to the set      #
	# strings to ensure that the correct files  #
	# are loaded during gameplay.               #
	#-------------------------------------------#
    def set_globals(self, difficulty):
        self.File1 = difficulty + 'OpenSpace.jpg'
        self.File2 = difficulty + 'ClosedSpace.jpg'
        self.File3 = difficulty + 'FinishSpace.jpg'
        self.File4 = difficulty + 'CharacterUp.jpg'
        self.File5 = difficulty + 'CharacterDown.jpg'
        self.File6 = difficulty + 'CharacterLeft.jpg'
        self.File7 = difficulty + 'CharacterRight.jpg'
        self.blocksDown = 12 + (Menu.DIFFICULTY * 6)
        self.blocksAcross = 18 + (Menu.DIFFICULTY * 9)

