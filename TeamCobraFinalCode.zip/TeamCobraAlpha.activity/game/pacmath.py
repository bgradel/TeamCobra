import spyral
import pygame
from pygame.locals import *
import random
import math
import Maze
import Menu
import correctpacman


board_layout = [
  "                               ",
  "    %%%%%%%%%%%%%%%%%%%%%%%    ",
  "    %.....................%    ",
  "    %.%.%%%.%%%%%%%.%%%.%.%    ",
  "    %.%.%......%......%.%.%    ",
  "    %.%.%.%%%%GGG%%%%.%.%.%    ",
  "    %...%.%.........%.%...%    ",
  "    %.%%%.%.%%%.%%%.%.%%%.%    ",
  "    %.....................%    ",
  "    %.%%%.%.%%%.%%%.%.%%%.%    ",
  "    %...%.%.........%.%...%    ",
  "    %.%.%.%%%%.%.%%%%.%.%.%    ",
  "    %.%.%......%......%.%.%    ",
  "    %.%.%%%.%%%%%%%.%%%.%.%    ",
  "    %..........P..........%    ",
  "    %%%%%%%%%%%%%%%%%%%%%%%    "]
SCORE1 = 0
board_width = 31
board_height = 16
ghost_velocity = 100
board_availability = []
WIDTH = 1200
HEIGHT = 900
speed = 0
NUMBERCORRECT = 0

def addFraction(fraction1, fraction2):
    '''
    Takes two fractions in the form of a tuple with (numerator, denominator) and returns a single
    tuple of the fraction which is the sum of the two (unsimplified)
    '''
    newNum = fraction1[0]*fraction2[1] + fraction2[0]*fraction1[1]
    newDen = fraction1[1]*fraction2[1]
    return (newNum, newDen)

primeNumbers = [2, 3, 5, 7, 11, 13, 17]

def reduceFraction(fraction):
    '''
    Takes a tuple with two ints. Uses the list of prime numbers from 2 to 20, and mods
    the numerator and denominatior by them to find the lowest form of the fraction.
    '''
    num = fraction[0]
    den = fraction[1]
    for p in primeNumbers:
        while num%p == 0 and den%p == 0:
            num = num/p
            den = den/p
    return (num, den)

def getFraction(number):
    num = random.randint(-5-(number*5), 5+(number*5))
    den = random.randint(2,5+(number*5))
    result = reduceFraction((num,den))
    while (result[1] == 1):
        num = random.randint(-5-(number*5), 5+(number*5))
        den = random.randint(2,5+(number*5))
        result = reduceFraction((num,den))
    return (result[0],result[1])

def generateAnswers():
    '''
    Returns a list with the two numbers that are added, their sum, and three answer (one for each ghost) one of which is correct,
    and two of which are incorrect.

    [tuple1, tuple2, sum, answer1, answer2, answer3]
    '''
    #addition of two numbers
    add1 = getFraction(Menu.DIFFICULTY)
    add2 = getFraction(Menu.DIFFICULTY)
    correctAnswer = reduceFraction(addFraction(add1, add2))
    #first incorrect answer
    incorrectNum1 = correctAnswer[0] + random.randint(-10,10)
    incorrectDen1 = correctAnswer[1] + random.randint(0,10)
    incorrect1 = reduceFraction((incorrectNum1, incorrectDen1))
    while (incorrect1[0] == correctAnswer[0] and incorrect1[1] == correctAnswer[1]):
        incorrectNum1 = correctAnswer[0] + random.randint(-10,10)
        incorrectDen1 = correctAnswer[1] + random.randint(0,10)
        incorrect1 = reduceFraction((incorrectNum1, incorrectDen1))
    #second incorrect answer
    incorrectNum2 = correctAnswer[0] + random.randint(-10,10)
    incorrectDen2 = correctAnswer[1] + random.randint(0,10)
    incorrect2 = reduceFraction((incorrectNum2, incorrectDen2))
    while (incorrect2[0] == correctAnswer[0] and incorrect2[1] == correctAnswer[1]) or (incorrect2[0] == incorrect1[0] and incorrect2[1] == incorrect1[1]):
        incorrectNum2 = correctAnswer[0] + random.randint(-10,10)
        incorrectDen2 = correctAnswer[1] + random.randint(0,10)
        incorrect2 = reduceFraction((incorrectNum2, incorrectDen2))
    returnList = [add1, add2, correctAnswer]
    y = [correctAnswer, incorrect1, incorrect2]
    while y != []:
        x = random.choice(y)
        returnList.append(x)
        y.remove(x)
    return returnList

class Box(spyral.Sprite) :
    def __init__(self, x, y, xBlock, yBlock, *args, **kwargs):
        spyral.sprite.Sprite.__init__(self)
        self.image = spyral.Image(size=(40, 40))
        self.image.fill((255,255,255))
        self.anchor = 'center'
        self.pos = (x, y)
        self.currentX = xBlock
        self.currentY = yBlock
        self.layer = 0
        self.available = 0

class TextSprite(spyral.Sprite) :
    def __init__(self, image, x, y, *args, **kwargs):
        spyral.sprite.Sprite.__init__(self)
        self.image = image
        self.anchor = 'midleft'
        self.pos = (x, y)

class IncorrectSprite(spyral.Sprite) :
    def __init__(self, x, y, *args, **kwargs):
        spyral.sprite.Sprite.__init__(self)
        self.image = spyral.Image(filename='Incorrect.jpg')
        self.anchor = 'midleft'
        self.layer = 3
        self.visible = False
        self.pos = (x, y)
		
class Empty(spyral.Sprite) :
    def __init__(self, x, y, xBlock, yBlock, *args, **kwargs):
        spyral.sprite.Sprite.__init__(self)
        self.image = spyral.Image(filename = 'NoPill.jpg')
        self.anchor = 'center'
        self.x = x
        self.y = y
        self.pos = (x, y)
        self.currentX = xBlock
        self.currentY = yBlock
        self.layer = 0
        self.available = 1	
		
class Pill(spyral.Sprite) :
    def __init__(self, x, y, xBlock, yBlock, *args, **kwargs):
        spyral.sprite.Sprite.__init__(self)
        self.image = spyral.Image(filename = 'Pill.jpg')
        self.anchor = 'center'
        self.x = x
        self.y = y
        self.pos = (x, y)
        self.currentX = xBlock
        self.currentY = yBlock
        self.layer = 0
        self.available = 2
    def turnToEmpty(self):
        global SCORE1
        self.image = spyral.Image(filename = 'NoPill.jpg')
        self.available = 1
        SCORE1 += 10
        
class Ghost(spyral.Sprite):
    def __init__(self, x, y, xBlock, yBlock, file, value, color, moving, *args, **kwargs):
        spyral.sprite.Sprite.__init__(self)
        fileToUse = file
        self.image = spyral.Image(filename = fileToUse)
        self.anchor = 'center'
        self.value = value
        self.x = x
        self.y = y
        self.pos = (x, y)
        self.currentX = xBlock
        self.currentY = yBlock
        self.moving = moving
        self.possibleActions = ['up', 'down', 'left', 'right']
        self.layer = 1

class PacMath(spyral.Scene):
    def __init__(self, *args, **kwargs):
        super(PacMath, self).__init__(*args, **kwargs)
        self.camera = self.parent_camera.make_child(virtual_size = (WIDTH, HEIGHT))
        self.group = spyral.Group(self.camera)
        global SCORE1
        pacman_image = spyral.Image(filename="PacmanLeft.jpg")
        self.pacman = spyral.Sprite()
        self.pacman.image = pacman_image
        self.pacman.anchor = 'center'
        self.pacman.x = 15*40
        self.pacman.y = 14*40
        self.pacman.currentX = 15
        self.pacman.currentY = 14
        self.pacman.layer = 2
        self.pacman.moving = False
        SCORE1 = Maze.SCORE
        self.incor1 = IncorrectSprite(720,690)
        self.incor2 = IncorrectSprite(720,740)
        self.incor3 = IncorrectSprite(720,790)
        self.group.add(self.incor1, self.incor2, self.incor3)
        self.display()
        i = 0
        j = 0
        for someString in board_layout:
            board_availability.append([])
        for someString in board_layout:
            i = 0
            for char in someString:
                if char == '%':
                    box=Box(i*40, j*40, i, j)
                    board_availability[j].append(box)
                    #self.group.add(box)
                elif char == '.' or char == 'G':
                    pill=Pill(i*40, j*40, i, j)
                    board_availability[j].append(pill)
                    self.group.add(pill)
                else:
                    empty=Empty(i*40, j*40, i, j)
                    board_availability[j].append(empty)
                    self.group.add(empty)
                i += 1
            j += 1
        self.group.add(self.pacman)
        font = spyral.Font(None, 64, (255, 255, 255))
        scoreText = spyral.Image(size=(100, 100))
        scoreText = font.render('Score: ' + unicode(SCORE1))
        self.scoreTextSprite = spyral.Sprite()
        self.scoreTextSprite.image = scoreText
        self.scoreTextSprite.anchor = 'midleft'
        self.scoreTextSprite.x = 200
        self.scoreTextSprite.y = 800
        self.group.add(self.scoreTextSprite)
        
    def score(self, side):
        pass    
        
    def on_enter(self):
        self.background = spyral.Image(size=(WIDTH, HEIGHT))
        self.background.fill((0,0,0))
        boximage = spyral.Image(size=(40, 40))
        boximage.fill((255,255,255))
        i = 0
        j = 0
        #for someString in board_layout:
        #    board_availability.append([])
        for someString in board_layout:
            i = 0
            for char in someString:
                if char == '%':
                    #box=Box(i*40, j*40, i, j)
                    self.background.draw_image(boximage, position = ((i*40)-600,(j*40)-450), anchor='center')
                else:
                    pass
                i += 1
            j += 1
        answer1ghost_image = spyral.Image(filename='Ghost1.jpg')
        answer2ghost_image = spyral.Image(filename='Ghost2.jpg')
        answer3ghost_image = spyral.Image(filename='Ghost3.jpg')
        self.background.draw_image(answer1ghost_image, position = (150,240), anchor='center')
        self.background.draw_image(answer2ghost_image, position = (150,290), anchor='center')
        self.background.draw_image(answer3ghost_image, position = (150,340), anchor='center')        
        self.camera.set_background(self.background)
        
    def render(self):
        # Simply tell the group to draw
        self.group.draw()
        
    def update(self, dt):
        global speed
        global SCORE1
        #global Maze.SCORE
        global NUMBERCORRECT
        self.group.update(dt)
        for event in self.event_handler.get():
            if event['type'] == 'QUIT':
                NUMBERCORRECT = 0
                for x in xrange(15):
                    board_availability.pop()
                self.group.remove(self.ghost1, self.ghost2, self.ghost3, self.textSprite, self.textSprite2, self.textSprite3, self.textSprite4, self.pacman)
                spyral.director.pop()
                return
            if event['type'] == 'KEYDOWN':
                if event['ascii'] == 'q':
                    NUMBERCORRECT = 0
                    for x in xrange(15):
                        board_availability.pop()
                        self.group.remove(self.ghost1, self.ghost2, self.ghost3, self.textSprite, self.textSprite2, self.textSprite3, self.textSprite4, self.pacman)
                    spyral.director.pop()  
                    return
                if event['key'] == spyral.keys.left:
                    self.pacman.moving = 'left'
                    pacman_image = spyral.Image(filename='PacmanLeft.jpg')
                    self.pacman.image = pacman_image
                if event['key'] == spyral.keys.right:
                    self.pacman.moving = 'right'
                    pacman_image = spyral.Image(filename='PacmanRight.jpg')
                    self.pacman.image = pacman_image
                if event['key'] == spyral.keys.up:
                    self.pacman.moving = 'up'
                    pacman_image = spyral.Image(filename='PacmanUp.jpg')
                    self.pacman.image = pacman_image
                if event['key'] == spyral.keys.down:
                    self.pacman.moving = 'down'
                    pacman_image = spyral.Image(filename='PacmanDown.jpg')
                    self.pacman.image = pacman_image
        
        pacman_velocity = 250
        
        def valid_move(character):
            if (character.moving == 'up' and (character.currentY-1 in xrange(board_height)) and (board_availability[character.currentY-1][character.currentX].available == 1 or board_availability[character.currentY-1][character.currentX].available == 2)):
                return True
            elif (character.moving == 'down' and (character.currentY+1 in xrange(board_height)) and (board_availability[character.currentY+1][character.currentX].available == 1 or board_availability[character.currentY+1][character.currentX].available == 2)):
                return True
            elif (character.moving == 'left' and (character.currentX-1 in xrange(board_width)) and (board_availability[character.currentY][character.currentX-1].available == 1 or board_availability[character.currentY][character.currentX-1].available == 2)):
                return True
            elif (character.moving == 'right' and (character.currentX+1 in xrange(board_width)) and (board_availability[character.currentY][character.currentX+1].available == 1 or board_availability[character.currentY][character.currentX+1].available == 2)):
                return True
            else:
                return False

        def move_and_correct(character):
            if (valid_move(character)):
                if (character.moving == 'up'):
                    character.y -= 40
                    character.currentY-=1
                elif (character.moving == 'down'):
                    character.y += 40
                    character.currentY+=1
                elif (character.moving == 'left'):
                    character.x -= 40
                    character.currentX-=1
                elif (character.moving == 'right'):
                    character.x += 40
                    character.currentX+=1
                else:
                    character.moving = False
            else:
                character.moving = False
            character.pos = (character.x, character.y)
       
        def get_opposite(direction):
            if (direction == 'up'):
                return 'down'
            elif (direction == 'down'):
                return 'up'
            elif (direction == 'left'):
                return 'right'
            else:
                return 'left'
		
        def resultx_spot(character):
            if (character.moving == 'up'):
                return character.currentX
            elif (character.moving == 'down'):
                return character.currentX
            elif (character.moving == 'left'):
                return character.currentX-1
            else:
                return character.currentX+1

        def resulty_spot(character):
            if (character.moving == 'up'):
                return character.currentY-1
            elif (character.moving == 'down'):
                return character.currentY+1
            elif (character.moving == 'left'):
                return character.currentY
            else:
                return character.currentY
            
        def move_and_correct_ghost(character):
            character.possibleActions = ['up', 'down', 'right', 'left']
            proceed = False
            if (((resultx_spot(character), (resulty_spot(character))) in self.taken) == False):
                proceed = True
            if (valid_move(character) and proceed == True):
                if (character.moving == 'up'):
                    character.moving = False
                    character.y -= 40
                    character.currentY-=1
                    character.possibleActions.remove('down')
                elif (character.moving == 'down'):
                    character.moving = False
                    character.y += 40
                    character.currentY+=1
                    character.possibleActions.remove('up')
                elif (character.moving == 'left'):
                    character.moving = False
                    character.x -= 40
                    character.currentX-=1
                    character.possibleActions.remove('right')
                elif (character.moving == 'right'):
                    character.moving = False
                    character.x += 40
                    character.currentX+=1
                    character.possibleActions.remove('left')
                int = random.randint(0, len(character.possibleActions) - 1)
                character.moving = character.possibleActions[int]
                character.pos = (character.x, character.y)
            else:
                int = random.randint(0, len(character.possibleActions) - 1)
                character.moving = character.possibleActions[int]
                move_and_correct_ghost(character)	
        #move_and_correct(self.pacman)
        
        if (speed == 12):
            self.taken = []
            self.taken = [(x.currentX, x.currentY) for x in self.ghosts]
            move_and_correct_ghost(self.ghost1)
            self.taken.append((self.ghost1.currentX, self.ghost1.currentY))
            move_and_correct_ghost(self.ghost2)
            self.taken.append((self.ghost2.currentX, self.ghost2.currentY))
            move_and_correct_ghost(self.ghost3)
			
        if (speed == 0 or speed == 6):
            move_and_correct(self.pacman)
        font = spyral.Font(None, 64, (255, 255, 255))
        scoreText = font.render('Score: ' + unicode(SCORE1))
        self.scoreTextSprite.image = scoreText
        speed = (speed + 1) % 13
        if (board_availability[self.pacman.currentY][self.pacman.currentX].available == 2):
            board_availability[self.pacman.currentY][self.pacman.currentX].available = 1
            self.group.remove(board_availability[self.pacman.currentY][self.pacman.currentX])
            SCORE1 = SCORE1 + 10
        for ghostx in self.ghosts:
            if (self.pacman.currentX == ghostx.currentX and self.pacman.currentY == ghostx.currentY):
                if (ghostx.value == self.question[2]):            
                    NUMBERCORRECT += 1
                    if (NUMBERCORRECT == 3):
                        NUMBERCORRECT = 0
                        for x in xrange(16):
                            board_availability.pop()
                            self.group.remove(self.ghost1, self.ghost2, self.ghost3, self.textSprite, self.textSprite2, self.textSprite3, self.textSprite4, self.pacman)
                        SCORE1 += (500+(100*Menu.DIFFICULTY))
                        Maze.SCORE = SCORE1
                        spyral.director.replace(correctpacman.Correct())
                    else:
                        self.group.remove(self.ghost1, self.ghost2, self.ghost3, self.textSprite, self.textSprite2, self.textSprite3, self.textSprite4)
                        pacman_image = spyral.Image(filename="PacmanLeft.jpg")
                        self.pacman.image = pacman_image
                        self.pacman.x = 15*40
                        self.pacman.y = 14*40
                        self.pacman.currentX = 15
                        self.pacman.currentY = 14
                        self.pacman.moving = False
                        SCORE1 += (500+(100*Menu.DIFFICULTY))
                        spyral.director.push(correctpacman.Correct())
                        self.display()
                else:
                    if (ghostx.value == self.question[3]):
                        self.incor1.visible = True
                    elif (ghostx.value == self.question[4]):
                        self.incor2.visible = True
                    else:
                        self.incor3.visible = True
                    self.ghosts.remove(ghostx)
                    self.group.remove(ghostx)
                    SCORE1 -= (300+(100*Menu.DIFFICULTY))
    def display(self):
        self.incor1.visible = False
        self.incor2.visible = False
        self.incor3.visible = False
        self.question = generateAnswers()
        arg1 = unicode(self.question[0][0])
        if (self.question[0][1] != 1):
            arg1 = arg1 + '/' + unicode(self.question[0][1])
        arg2 = unicode(self.question[1][0])
        if (self.question[1][1] != 1):
            arg2 = arg2	+ '/' + unicode(self.question[1][1])
        q1 = unicode(self.question[3][0])
        if (self.question[3][1] != 1):
            q1 = q1 + '/' + unicode(self.question[3][1])
        q2 = unicode(self.question[4][0])
        if (self.question[4][1] != 1):
            q2 = q2 + '/' + unicode(self.question[4][1])
        q3 = unicode(self.question[5][0])
        if (self.question[5][1] != 1):
            q3 = q3 + '/' + unicode(self.question[5][1])
        equation = arg1 + ' + ' + arg2 + ' = ?'
        answer1 = q1
        answer2 = q2
        answer3 = q3
        font = spyral.Font(None, 64, (255, 255, 255))
        text = spyral.Image(size=(100, 100))
        text = font.render(equation)
        text2 = spyral.Image(size=(100, 100))
        text2 = font.render(q1)
        text3 = spyral.Image(size=(100, 100))
        text3 = font.render(q2)
        text4 = spyral.Image(size=(100, 100))
        text4 = font.render(q3)
        self.textSprite = TextSprite(text, 200, 675)
        self.textSprite2 = TextSprite(text2, 800, 690)
        self.textSprite3 = TextSprite(text3, 800, 740)
        self.textSprite4 = TextSprite(text4, 800, 790)
        self.group.add(self.textSprite, self.textSprite2, self.textSprite3, self.textSprite4)#, self.answer1ghost, self.answer2ghost, self.answer3ghost)
        self.ghost1 = Ghost(14*40,6*40, 14, 6, 'Ghost1.jpg', self.question[3], (0, 255, 255), 'left')
        self.ghost2 = Ghost(15*40,6*40, 15, 6, 'Ghost2.jpg', self.question[4],  (255, 0, 0), 'up')
        self.ghost3 = Ghost(16*40,6*40, 16, 6, 'Ghost3.jpg', self.question[5], (0,255, 0), 'right')
        self.ghosts = [self.ghost1, self.ghost2, self.ghost3]
        self.group.add(self.ghost1)
        self.group.add(self.ghost2)
        self.group.add(self.ghost3)
