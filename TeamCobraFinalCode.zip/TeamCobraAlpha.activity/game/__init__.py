import spyral
import Menu

def main():
    spyral.director.push(Menu.MainMenu())
    return
