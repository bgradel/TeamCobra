import spyral
import Maze

WIDTH = 1200
HEIGHT = 900
DIFFICULTY = 0

class Arrow(spyral.Sprite):
    #--------------- THE ARROW CLASS ---------------#
    # The arrow class is used as a selection tool   #
    # in the main menu and the difficulty menu.     #
	# The arrow keys are used to move the arrow.    #
    #-----------------------------------------------#
    def __init__(self, newFacing, newX, newY, newCurrentOption, newNumOfOptions, newChange, newMakeFlip, newMoves):
        super(Arrow, self).__init__()
        self.anchor = 'center'
        arrow_image = spyral.Image(filename='Arrow.jpg')
        self.image = arrow_image
        if (newFacing == 'L'):
            self.flip_x = True
        self.x = newX
        self.y = newY
        self.pos = (self.x, self.y)
        self.currentOption = newCurrentOption
        self.numOfOptions = newNumOfOptions
        self.change = newChange
        self.makeFlip = newMakeFlip
        self.moves = newMoves
        self.visible = True
        self.moving = False
        self.layer = 1
    #---------------- valid_move ---------------#
    # The valid_move function checks to see     #
	# whether or not the arrow is able to move  #
 	# in the given direction.                   #
	#-------------------------------------------#
    def valid_move(self):
        if ((self.moving == 'left' or self.moving == 'right') and (self.moves == 'LR')):
            if (self.moving == 'left'):
                return (self.currentOption > 1)
            else:
                return (self.currentOption < self.numOfOptions)
        elif ((self.moving == 'up' or self.moving == 'down') and (self.moves == 'UD')):
            if (self.moving == 'up'):
                return (self.currentOption > 1)
            else:
                return (self.currentOption < self.numOfOptions)
        else:
            return False
    #---------------- move_and_correct ---------------#
    # If the given move is valid, the move_and_correct#
	# function will change the location of the arrow  #
	# and also the currently highlighted option.      #
	#-------------------------------------------------#
    def move_and_correct(self):
        if (self.valid_move()):
            if (self.moves == 'LR'):
                if (self.moving == 'left'):
                    self.x -= self.change
                    self.currentOption -= 1
                    self.flip_x = False
                else:
                    self.x += self.change
                    self.currentOption += 1
                    self.flip_x = self.makeFlip
            else:
                if (self.moving == 'up'):
                    self.y -= self.change
                    self.currentOption -= 1
                else:
                    self.y += self.change
                    self.currentOption += 1
        self.moving = False
        self.pos = (self.x, self.y)
    #---------------- set_move ---------------#
    # When the action listener recieves an    #
	# action,the set_move function will store #
	# the action in the arrow's 'moving'      #
	# attribute.                              #
	#-----------------------------------------#
    def set_move(self, event):
        if event['type'] == 'KEYDOWN':
            if event['key'] == spyral.keys.left:
                self.moving = 'left'
            if event['key'] == spyral.keys.right:
                self.moving = 'right'
            if event['key'] == spyral.keys.up:
                self.moving = 'up'
            if event['key'] == spyral.keys.down:
                self.moving = 'down'

class MainMenu(spyral.Scene):
    #--------------- THE MAIN MENU ---------------#
    # The main menu contains a background image   # 
    # and an arrow with two different options.    #
    # The 's' key is used to select an option.    #
    #---------------------------------------------#
    def __init__(self, *args, **kwargs):
        super(MainMenu, self).__init__(*args, **kwargs)
        self.camera = self.parent_camera.make_child(virtual_size = (WIDTH, HEIGHT))
        self.group = spyral.Group(self.camera)
        self.arrow = Arrow('R',510,766,1,1,0,False,'LR')
        self.group.add(self.arrow)
    def on_enter(self):
        background = spyral.Image(filename='MainMenuBackground.jpg')
        self.camera.set_background(background)
    def render(self):
        self.group.draw()
    def update(self, dt):
        self.group.update(dt)
        for event in self.event_handler.get():
            if event['type'] == 'QUIT':
                spyral.director.pop()
            if event['type'] == 'KEYDOWN':
                self.arrow.set_move(event)
                if event['ascii'] == 's':
                    if (self.arrow.currentOption == 1):
                        spyral.director.push(DifficultyMenu())
                self.arrow.move_and_correct()

class DifficultyMenu(spyral.Scene):
    #--------------- THE DIFFICULTY MENU ---------------#
    # The difficulty menu contains a background image   #
    # and an arrow with three different options.  The   #
    # 's' key is used to select an option, and the 'b'  #
    # key is used to go back to the main menu.          #
    #---------------------------------------------------#
    def __init__(self, *args, **kwargs):
        super(DifficultyMenu, self).__init__(*args, **kwargs)
        self.camera = self.parent_camera.make_child(virtual_size = (WIDTH, HEIGHT))
        self.group = spyral.Group(self.camera)
        self.arrow = Arrow('L',920,645,1,3,63,False,'UD')
        self.group.add(self.arrow)
    def on_enter(self):
        background = spyral.Image(filename='DifficultyMenuBackground.jpg')
        self.camera.set_background(background)
    def render(self):
        self.group.draw()
    def update(self, dt):
        self.group.update(dt)
        global DIFFICULTY
        for event in self.event_handler.get():
            if event['type'] == 'QUIT':
                spyral.director.pop()
            if event['type'] == 'KEYDOWN':
                self.arrow.set_move(event)
                if event['ascii'] == 's':
                    DIFFICULTY = (self.arrow.currentOption-1)
                    spyral.director.replace(Maze.Maze())
                if event['ascii'] == 'b':
                    spyral.director.pop()
                self.arrow.move_and_correct()				