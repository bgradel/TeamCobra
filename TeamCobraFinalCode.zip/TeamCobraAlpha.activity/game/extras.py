import spyral
import math
from decimal import Decimal
import battleship
import Menu
import string
pyFraction = __import__('fractions')

#FONT_PATH = "fonts/00TT.TTF
FONT_PATH = None

#Essentially just a wrapper for a rectangle with click detection.
#I have been using it as the base for a button.  Once you make one of these,
#just make some Text and layer the Text on top of the Button
class Button(spyral.Sprite):
    def __init__(self, position, image_size=None, filename=None, anchor='center', layer='all', fill=(255,255,0), group=None):

        super(Button, self).__init__(group)
            
        if filename == None and image_size != None:
            self.image = spyral.Image(size=image_size)
            self.image.fill(fill)
        elif filename != None:
            self.image = spyral.Image(filename)
        else:
            raise ValueError("Need either a filename or an image_size")
        
        self.layer = layer
        self.anchor = anchor
        self.pos = position

    def check_click(self, position):
        return self.get_rect().collide_point(position)

#I've used it as the top layer of a button, but could be used for text anywhere on the screen
#Generates a sprite from some text, size and position. Currenlty defaults to the font constant,
#but that can easily be changed to support multiple fonts
class Text(spyral.Sprite):
    def __init__(self, text, image_size, position, anchor='center', layer='all', font_size=48, color=(0,0,0), group=None):

        super(Text, self).__init__()
        #self.image = spyral.Image(size=image_size)
        self.font_size = font_size
        self.color = color
        self.image = spyral.Font(FONT_PATH, font_size, color).render(text)
        self.layer = layer
        self.anchor = anchor
        self.pos = position
        self.text = text

    def set_text(self, text):
        self.image = spyral.Font(FONT_PATH, self.font_size, self.color).render(text)
        self.text = text
    def get_text(self):
        return self.text

class TextBox(spyral.Sprite):
    def __init__(self,dtext,position,answer, color, button_image="",width=200,height=50,anchor='center',layer='all',font_size=48):

        super(TextBox,self).__init__()
        self.answer = answer
        self.selected = 0
	self.correct = 0

        self.wdth = width
        self.heght = height
        
        self.dtext = dtext
        self.position = position
        self.button_image = button_image
        self.anchor = anchor
        self.font_size = font_size
        self.tcolor = (0,0,0)
        self.dcolor = color

        self.description = Text(dtext,64,(position[0],position[1]-50),anchor=self.anchor,color=self.dcolor,font_size=self.font_size)
        
        self.button = spyral.Sprite()
        self.button.image = spyral.Image(size = (width,height))
        #self.button.image.fill((255,255,255))
        self.button.image.fill(color)
        self.button.anchor = self.anchor
        self.button.pos = (self.position[0],self.position[1]-5)
        self.button.layer = 1

        self.btext = Text("",64,position,layer=100,anchor=self.anchor,color=self.tcolor,font_size=self.font_size)
        self.btext.layer = 10
        
        if(button_image != ""):
            self.button.image = spyral.Image(filename=self.button_image)
            
    def set_text(self, text):
        self.btext.image = spyral.Font(FONT_PATH, self.font_size, self.tcolor).render(text)
        self.btext.text = text
        self.btext.layer = 10
    def get_text(self):
        return self.btext.text

    def check_click(self, position):
        self.ret = self.button.get_rect().collide_point(position)
        return self.ret
    def select(self,tpe):
	if self.correct == 0:
            tpe.type = self
            self.button.image = spyral.Image(size = (self.wdth,self.heght))
            self.button.image.fill(self.dcolor)
            self.button.anchor = self.anchor
	return 0
    def deselect(self):
        #self.button.image = spyral.Image(size = (self.wdth,self.heght))
        #self.button.image.fill((255,255,255))
        #self.button.anchor = self.anchor
        return 0
    def move(self,pos):
        return 0
    def get_answer(self):
	'''
        self.set_text(filter(lambda x: x.isdigit(), self.get_text()))
        if(self.get_text() == ""):
            self.set_text("-1")
        print "Converted to Integer: "+self.get_text()
	'''
        #if(float(self.get_text()) == self.answer):
	try:
	    userInput = float(self.get_text())
	except ValueError:
	    self.set_text(self.btext.text[:-1])
	    self.button.image = spyral.Image(size = (self.wdth,self.heght))
            self.button.image.fill((255,0,0))
	    return -1
	if self.correct == 1:
	    self.set_text(self.btext.text[:-1])
	    return 0	
	elif (Decimal(str(self.get_text())).quantize(Decimal('.01')) == self.answer):
            #self.set_text("Correct!")
	    self.set_text(self.btext.text[:-1])
            #self.btext.text = ""
	    self.correct = 1
	    self.button.image = spyral.Image(size = (self.wdth,self.heght))
            self.button.image.fill((0,255,0))
            self.button.anchor = self.anchor
	    return 1
        else:
            #self.set_text("Wrong - Correct Answer: "+str(self.answer))
	    #self.set_text("Try again!")
            #self.btext.text = ""
	    self.set_text(self.btext.text[:-1])
	    self.button.image = spyral.Image(size = (self.wdth,self.heght))
            self.button.image.fill((255,0,0))
            self.button.anchor = self.anchor
	    return 0

    def get_answer_list(self, list):
	'''
        self.set_text(filter(lambda x: x.isdigit(), self.get_text()))
        if(self.get_text() == ""):
            self.set_text("-1")
        print "Converted to Integer: "+self.get_text()
	'''	
        #if(float(self.get_text()) == self.answer):
        #try:
        #    userInput = float(self.get_text())
        #except ValueError:
        #    print("No.")
        #    self.set_text(self.btext.text[:-1])
        #    self.button.image = spyral.Image(size = (self.wdth,self.heght))
        #    self.button.image.fill((255,0,0))
        #    return -1
        #print userInput
        #print self.get_text()
        input =  self.get_text()
        #print input
        input = [input[:-1]]
        input = input[0]
        input = [string.replace(input, " ", "")]
        #if self.correct == 1:
         #   self.set_text(self.btext.text[:-1])
          #  return 0
        if (input in list):
            global ANSWERS
            #if (input in 
            battleship.ANSWERS.remove(input)
            #self.set_text("Correct!")
            self.set_text(self.btext.text[:-1])
            #self.btext.text = ""
            self.correct = 1
            self.button.image = spyral.Image(size = (self.wdth,self.heght))
            self.button.image.fill((255,255,255))
            self.button.anchor = self.anchor
            self.set_text('')
            battleship.SCORE2 += (100 + (50*Menu.DIFFICULTY))
            return input
        else:
            #self.set_text("Wrong - Correct Answer: "+str(self.answer))
            #self.set_text("Try again!")
            #self.btext.text = ""
            self.set_text(self.btext.text[:-1])
            self.button.image = spyral.Image(size = (self.wdth,self.heght))
            self.button.image.fill((255,255,255))
            self.button.anchor = self.anchor
            self.set_text('')
            battleship.SCORE2 -= (50 + (50*Menu.DIFFICULTY))
            battleship.MISSES.append(input)
            return 0
