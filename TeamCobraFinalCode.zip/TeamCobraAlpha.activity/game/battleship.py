import spyral
import random
import math
import extras
import Maze 
import os.path 
import sys
import string

WIDTH = 1200
HEIGHT = 900
SCORE2 = 0
battlefield = []
actions = ['up', 'down', 'left', 'right']
NUMBEROFSHIPSLEFT = 0
ANSWERS = []
SCORE1 = 0
MISSES = []

class TextSprite(spyral.Sprite) :
    def __init__(self, image, x, y, *args, **kwargs):
        spyral.sprite.Sprite.__init__(self)
        self.image = image
        self.anchor = 'midleft'
        self.pos = (x, y)


class ShipBlock(spyral.Sprite) :
    def __init__(self, x, y, xBlock, yBlock, gX, gY, *args, **kwargs):
        spyral.sprite.Sprite.__init__(self)
        self.image = spyral.Image(filename = 'Ship.jpg')
       # self.image.fill((0,0,0))
        self.anchor = 'center'
        self.x = x
        self.y = y
        self.pos = (x, y)
        self.currentX = xBlock
        self.currentY = yBlock
        self.gridX = gX
        self.gridY = gY
        self.layer = 0
        self.empty = 0
        self.hit = 0
    def turnToShipBlockHit(self):
        self.image = spyral.Image(filename = 'ShipHit.jpg')
        self.hit = 1

class ShipBlockHit(spyral.Sprite) :
    def __init__(self, x, y, xBlock, yBlock, gX, gY, *args, **kwargs):
        spyral.sprite.Sprite.__init__(self)
        self.image = spyral.Image(filename = 'ShipHit.jpg')
        self.anchor = 'center'
        self.x = x
        self.y = y
        self.pos = (x, y)
        self.currentX = xBlock
        self.currentY = yBlock
        self.gridX = gX
        self.gridY = gY
        self.layer = 0
        self.empty = 0
        self.hit = 1		
		
class EmptyBlock(spyral.Sprite) :
    def __init__(self, x, y, xBlock, yBlock, gX, gY, *args, **kwargs):
        spyral.sprite.Sprite.__init__(self)
        self.image = spyral.Image(filename='Open.jpg')
        self.anchor = 'center'
        self.x = x
        self.y = y
        self.pos = (x, y)
        self.currentX = xBlock
        self.currentY = yBlock
        self.gridX = gX
        self.gridY = gY
        self.layer = 0
        self.empty = 1
        self.miss = 0	
    def turnToShipBlock(self):
        self.image = spyral.Image(filename = 'Ship.jpg')
        self.empty = 0
        self.hit = 0
    def turnToEmptyBlockMiss(self):
        self.image = spyral.Image(filename = 'OpenMiss.jpg')
        self.empty = 1
        self.miss = 1
    def turnToShipBlockHit(self):
        self.image = spyral.Image(filename = 'ShipHit.jpg')
        self.hit = 1
        self.empty = 0
		
class EmptyBlockMiss(spyral.Sprite) :
    def __init__(self, x, y, xBlock, yBlock, gX, gY, *args, **kwargs):
        spyral.sprite.Sprite.__init__(self)
        self.image = spyral.Image(filename = 'OpenMiss.jpg')
        self.anchor = 'center'
        self.x = x
        self.y = y
        self.pos = (x, y)
        self.currentX = xBlock
        self.currentY = yBlock
        self.gridX = gX
        self.gridY = gY
        self.layer = 0
        self.empty = 1
        self.hit = 0	

class Battleship(spyral.Scene):
    def __init__(self, *args, **kwargs):
        super(Battleship, self).__init__(*args, **kwargs)
        self.camera = self.parent_camera.make_child(virtual_size = (WIDTH, HEIGHT))
        self.group = spyral.Group(self.camera)
	global MISSES
	self.text = spyral.Group(self.camera)
        global SCORE2
        SCORE2 = Maze.SCORE
	self.multiselect = 0
	self.multimax = 1
        self.yinterval = random.randint(1,10)
        for x in xrange(5):
            font = spyral.Font(None, 40, (255, 255, 255))
            text = spyral.Image(size=(100, 50))
            text = font.render(unicode(self.yinterval*x*2))
            self.textSprite = spyral.Sprite()
            self.textSprite.image = text
            self.textSprite.anchor = 'midright'
            self.textSprite.x = 510
            self.textSprite.y = 640-(60*x*2)
            self.group.add(self.textSprite)
        self.xinterval = random.randint(1,10)
        for x in xrange(5):
            font = spyral.Font(None, 40, (255, 255, 255))
            text = spyral.Image(size=(100, 50))
            text = font.render(unicode(self.xinterval*x*2))
            self.textSprite = spyral.Sprite()
            self.textSprite.image = text
            self.textSprite.anchor = 'midtop'
            self.textSprite.x = 550+ (60*x*2)
            self.textSprite.y = 680
            self.group.add(self.textSprite)
        for y in xrange(10):
            battlefield.append([])
        for y in xrange(10):
            for x in xrange(10):
                empty = EmptyBlock((x*60)+550,(y*60)+100,x,y, x*self.xinterval, y*self.yinterval)
                battlefield[y].append(empty)
                self.group.add(empty)
        self.placeShip(2)
        self.placeShip(3)
        self.placeShip(3)
        self.placeShip(5)
        font = spyral.Font(None, 64, (255, 255, 255))
        scoreText = spyral.Image(size=(100, 100))
        scoreText = font.render('Score: ' + unicode(SCORE2))
        self.scoreTextSprite = spyral.Sprite()
        self.scoreTextSprite.image = scoreText
        self.scoreTextSprite.anchor = 'midleft'
        self.scoreTextSprite.x = 160
        self.scoreTextSprite.y = 700
        self.group.add(self.scoreTextSprite)
        #for x in xrange(10): 
        self.textboxes = []
        '''
        self.xinput = extras.TextBox(str('(') + '' + str(')'), (500, 800), x)

        self.yinput = extras.TextBox(str('(') + '' + str(')'), (800, 800), y)
        '''
        self.xinput = extras.TextBox("Enter as X,Y: ", (255, 500), ANSWERS, (255,255,255))

        #self.yinput = extras.TextBox('Y-Value:', (200, 450), ANSWERS)                              
        self.xinput.select(self)
        self.textboxes.append(self.xinput)

        #self.textboxes.append(self.yinput)
        for box in self.textboxes: 
            self.text.add(box.description)
            self.text.add(box.btext)
            self.group.add(box.button) 
    
    #def validAnswers(self,):
    # for loop through x or y
    # check answer versus what input is
    # return value of answer if correct, on error give something that is not a number

    def check_click(self, position, group, select):
         local_position = self.camera.world_to_local(position)
         for sprite in group:
             sprite.deselect()
             if sprite.check_click(local_position):
                 sprite.move(local_position)
               	 if(select == 1)and(self.multiselect < self.multimax):
                     sprite.select(self)
                     self.multiselect += 1
       	 self.multiselect = 0

    def deselect(self,List):
        for obj in List:
            if(obj.selected == 1):
                obj.deselect()

    def get_type(self,Text):
        return Text.get_text()

    def set_type(self,text,Text):
        return Text.set_text(text)

		
    def on_enter(self):
        self.background = spyral.Image(size=(WIDTH,HEIGHT))
        self.background.fill((0,0,0))
        added_image = spyral.Image(filename='Battleship.jpg')
        self.background.draw_image(added_image, position = (-350,-275), anchor = 'center')
        self.camera.set_background(self.background)

    def render(self):
        # Simply tell the group to draw
        self.group.draw()
	self.text.draw()


    def promptUser(self):
        global NUMBEROFSHIPSLEFT
        global SCORE2
         
        userX = input('Please enter an x-value: ')
        userY = input('Please enter a y-value: ')
        xblock = userX/self.xinterval
        yblock = 9 - (userY/self.yinterval)
        
        font = spyral.Font(None, 64, (255, 255, 255))
        scoreText
        if (battlefield[yblock][xblock].empty == 0 and battlefield[yblock][xblock].hit == 0):
            battlefield[yblock][xblock].turnToShipBlockHit()
            SCORE2 += 50
            NUMBEROFSHIPSLEFT -= 1
        elif (battlefield[yblock][xblock].empty == 1 and battlefield[yblock][xblock].miss == 0):
            battlefield[yblock][xblock].turnToEmptyBlockMiss()
            SCORE2 -= 50
        else:
            self.promptUser()
		
    def update(self, dt):
        """
        The update loop receives dt as a parameter, which is the amount
        of time which has passed since the last time update was called.
        """
        global NUMBEROFSHIPSLEFT
        global battlefield
        global SCORE2
        global ANSWERS
        #global Maze.SCORE
        self.group.update(dt)
        input = 0
        # Gets all the events from the event handler
	'''
        for event in self.event_handler.get():
            # You should always be sure you're handling the quit events
            if event['type'] == 'QUIT':
                for x in xrange(10):
                    battlefield.pop()
                spyral.director.pop()  # Happens when someone asks the OS to close the program
                return
            if event['type'] == 'KEYDOWN':
                if event['ascii'] == 's':
                    if (NUMBEROFSHIPSLEFT > 0):
                        self.promptUser()
                        print ''
                        if (NUMBEROFSHIPSLEFT == 0):
                            for x in xrange(10):
                                battlefield.pop()
                            Maze.SCORE = SCORE2
                            spyral.director.pop()
        font = spyral.Font(None, 64, (255, 255, 255))
        scoreText = font.render('Score: ' + unicode(SCORE2))
        self.scoreTextSprite.image = scoreText 
	'''
         #self.group.update(dt)
        for event in self.event_handler.get():
            if event['type'] == 'QUIT':
                for x in xrange(10):
                    battlefield.pop()
                spyral.director.pop()
                return
            elif event['type'] == 'KEYDOWN':		
		self.ntext = self.get_type(self.type) + event['ascii']
		self.set_type(self.ntext, self.type)
                if event['ascii'] == 'q' or event['ascii'] == chr(27):
                    for x in xrange(10):
                        battlefield.pop()
                    spyral.director.pop()
                    return

		elif event['ascii'] == chr(13):
			 input = self.type.get_answer_list(ANSWERS)
			 if (len(ANSWERS) < 1):
				 Maze.SCORE = SCORE2
                                 for x in xrange(10):
                                     battlefield.pop()
				 spyral.director.pop()
		elif event['ascii'] == chr(8):
			txt = str(self.get_type(self.type))
			txt = txt[:len(txt)-2]
			self.set_type(txt,self.type)
		
	    elif event['type'] == "MOUSEBUTTONDOWN":
                self.check_click(event['pos'], self.textboxes,1)
            elif event['type'] == "MOUSEBUTTONUP":
                self.deselect(self.textboxes)
        font = spyral.Font(None, 64, (255, 255, 255))
        scoreText = font.render('Score: ' + unicode(SCORE2))
        self.scoreTextSprite.image = scoreText
        if (input != 0 and len(ANSWERS) > 0):
            input = input[0]
            input = input.split(',')
            xcord = int(input[0])/self.xinterval
            ycord = 9 - (int(input[1])/self.yinterval)
            battlefield[ycord][xcord].turnToShipBlockHit()
    def openPath(self, direction, x, y, size):
        size -= 1
        if (direction == 'up'):
            while (size > 0):
                if (battlefield[y-size][x].empty == 0):
                    return False
                else:
                    size -= 1
        elif (direction == 'down'):
            while (size > 0):
                if (battlefield[y+size][x].empty == 0):
                    return False
                else:
                    size -= 1
        elif (direction == 'left'):
            while (size > 0):
                if (battlefield[y][x-size].empty == 0):
                    return False
                else:
                    size -= 1
        elif (direction == 'right'):
            while (size > 0):
                if (battlefield[y][x+size].empty == 0):
                    return False
                else:
                    size -= 1
        return True

    def placeShip(self, size):
        global NUMBEROFSHIPSLEFT
        global battlefield
        global ANSWERS
        randx = random.randint(0,9)
        randy = random.randint(0,9)
        selection = random.randint(0,3)
        action = actions[selection]
        if (action == 'up'):
            if (battlefield[randy][randx].empty == 1 and (randy-(size-1) in xrange(10)) and self.openPath('up', randx, randy, size)):
                size -= 1
                while (size >= 0):
                    NUMBEROFSHIPSLEFT += 1
                    battlefield[randy-size][randx].turnToShipBlock()
                    ANSWERS.append([str((randx)*self.xinterval) + ',' + str(9*self.yinterval-(self.yinterval*(randy-size)))])
                    size -= 1
            else:
                self.placeShip(size)
        elif (action == 'down'):
            if (battlefield[randy][randx].empty == 1 and (randy+(size-1) in xrange(10)) and self.openPath('down', randx, randy, size)):
                size -= 1
                while (size >= 0):
                    NUMBEROFSHIPSLEFT += 1
                    battlefield[randy+size][randx].turnToShipBlock()
                    ANSWERS.append([str((randx)*self.xinterval) + ',' + str(9*self.yinterval-(self.yinterval*(randy+size)))])
                    size -= 1
            else:
                self.placeShip(size)
        elif (action == 'left'):
            if (battlefield[randy][randx].empty == 1 and (randx-(size-1) in xrange(10)) and self.openPath('left', randx, randy, size)):
                size -= 1
                while (size >= 0):
                    NUMBEROFSHIPSLEFT += 1
                    battlefield[randy][randx-size].turnToShipBlock()
                    ANSWERS.append([str((randx-size)*self.xinterval) + ',' + str(9*self.yinterval-(self.yinterval*randy))])
                    size -= 1
            else:
                self.placeShip(size)
        elif (action == 'right'):
            if (battlefield[randy][randx].empty == 1 and (randx+(size-1) in xrange(10)) and self.openPath('right', randx, randy, size)):
                size -= 1
                while (size >= 0):
                    NUMBEROFSHIPSLEFT += 1
                    battlefield[randy][randx+size].turnToShipBlock()
                    ANSWERS.append([str((randx+size)*self.xinterval) + ',' + str(9*self.yinterval-(self.yinterval*randy))])
                    size -= 1
            else:
                self.placeShip(size)
