import spyral
import random
import math
import extras
import Maze 
import os.path 
import sys
import string
import battleship
import Shopping
import pacmath

WIDTH = 1200
HEIGHT = 900

class TextSprite(spyral.Sprite) :
    def __init__(self, image, x, y, *args, **kwargs):
        spyral.sprite.Sprite.__init__(self)
        self.image = image
        self.anchor = 'midleft'
        self.pos = (x, y)
        self.visible = True
		
class Instructions(spyral.Scene):
    def __init__(self, *args, **kwargs):
        super(Instructions, self).__init__(*args, **kwargs)
        self.camera = self.parent_camera.make_child(virtual_size = (WIDTH, HEIGHT))
        self.group = spyral.Group(self.camera)
        font = spyral.Font(None, 85, (255, 255, 255))
        text = spyral.Image(size=(100,100))
        text = font.render(unicode(Maze.SCORE))
        self.scoreSprite = TextSprite(text, 600, 550)
        if (Maze.CURRENTGAME == 'Done'):
            self.group.add(self.scoreSprite)
        else:
            pass
        
    def on_enter(self):
        if (Maze.CURRENTGAME == 'Battleship'):
            background = spyral.Image(filename='BattleshipInstructions.jpg')
        elif (Maze.CURRENTGAME == 'Shopping'):
            background = spyral.Image(filename='ShoppingInstructions.jpg')
        elif (Maze.CURRENTGAME == 'PacMath'):
            background = spyral.Image(filename='PacMathInstructions.jpg')
        else:
            background = spyral.Image(filename='ScoreBackground.jpg')
        self.camera.set_background(background)
    def render(self):
        self.group.draw()
    def update(self, dt):
        self.group.update(dt)
        for event in self.event_handler.get():
            if event['type'] == 'QUIT':
                spyral.director.pop()
            if event['type'] == 'KEYDOWN':
                if event['ascii'] == 's':
                    if (Maze.CURRENTGAME == 'Battleship'):
                        spyral.director.replace(battleship.Battleship())
                    elif (Maze.CURRENTGAME == 'Shopping'):
                        spyral.director.replace(Shopping.Shop())
                    elif (Maze.CURRENTGAME == 'PacMath'):
                        spyral.director.replace(pacmath.PacMath())
                    else:
                        spyral.director.pop()
                else:
                    pass
            else:
                pass
