import spyral
import random
import math
import Maze

WIDTH = 1200
HEIGHT = 900
DIFFICULTY = 0

#-------------------- THE MENU CLASS --------------------#
class Menu(spyral.Scene):
    def __init__(self, *args, **kwargs):
        super(Menu, self).__init__(*args, **kwargs)
        self.camera = self.parent_camera.make_child(virtual_size = (WIDTH, HEIGHT))
        self.group = spyral.Group(self.camera)
        self.arrow = spyral.Sprite()
        self.arrow.anchor = 'center'
        self.arrow.option = 0
        self.arrow.x = 920
        self.arrow.y = 645
        self.arrow.pos = (self.arrow.x, self.arrow.y)
        arrow_image = spyral.Image(filename='Arrow.jpg')
        self.arrow.image = arrow_image
        self.arrow.flip_x = True
        self.arrow.visible = True
        self.arrow.moving = False
        self.arrow.layer = 2
        self.group.add(self.arrow)
    def on_enter(self):
        background = spyral.Image(filename='DifficultyMenuBackground.jpg')
        self.camera.set_background(background)
    def render(self):
        self.group.draw()
    def update(self, dt):
        """
        The update loop receives dt as a parameter, which is the amount
        of time which has passed since the last time update was called.
        """
        global DIFFICULTY
        self.group.update(dt)
        for event in self.event_handler.get():
            if event['type'] == 'QUIT':
                spyral.director.pop()
                return
            if event['type'] == 'KEYDOWN':
                if event['key'] == spyral.keys.up:
                    self.arrow.moving = 'up'
                if event['key'] == spyral.keys.down:
                    self.arrow.moving = 'down'
                if event['ascii'] == 's':
                    if (self.arrow.option == 0):
                        DIFFICULTY = 0
                        spyral.director.replace(maze.Maze())
                    elif (self.arrow.option == 1):
                        DIFFICULTY = 1
                        spyral.director.replace(maze.Maze())
                    elif (self.arrow.option == 2):
                        DIFFICULTY = 2
                        spyral.director.replace(maze.Maze())
                    else:
                        pass
                if event['ascii'] == 'b':
                    spyral.director.pop()
            elif event['type'] == 'KEYUP':
                if event['key'] in (spyral.keys.up, spyral.keys.down):
                    self.arrow.moving = False

        def valid_move(arrow):
            if (arrow.moving == 'up' and arrow.option > 0):
                return True
            elif (arrow.moving == 'down' and arrow.option < 2):
                return True
            else:
                return False

        def move_and_correct(arrow):
            if (valid_move(arrow)):
                if (arrow.moving == 'up'):
                    arrow.moving = False
                    arrow.y -= 63
                    arrow.option-=1
                    arrow.flip_x = True
                elif (arrow.moving == 'down'):
                    arrow.moving = False
                    arrow.y += 63
                    arrow.option+=1
                    arrow.flip_x = True
                else:
                    arrow.moving = False
            else:
                arrow.moving = False
            arrow.pos = (arrow.x, arrow.y)

        move_and_correct(self.arrow)
