import pygame
import spyral
import extras
import random
import math
import operator
import os.path
import sys
import Maze
from decimal import Decimal

WIDTH = 1200
HEIGHT = 900
FONT_SIZE = 42
SCORE1 = 0

LEVEL = 1

class Purchasable:
    def __init__(self, image, price, index):
	self.image = image
	self.price = price
	self.index = index

class Item (spyral.Sprite):
    #Everything sold in the shop is an Item object
    def __init__ (self, image, price, index, x, y, name = "", discount=0, *args, **kwargs):
        super(Item, self).__init__()
        spyral.sprite.Sprite.__init__(self)
        self.image = spyral.Image(image)
        #self.price = price
	self.price = Decimal(str(price)).quantize(Decimal('.01'))
	self.discount = discount
        self.index = index #index of item in list of all possibleItems	
        self.x = x
        self.y = y
        self.pos = (x, y)
        self.name = image
        if self.name.endswith('.png'):
            self.name = self.name[:-4]

class Shop (spyral.Scene):
    def __init__(self, *args, **kwargs):
        super(Shop, self).__init__(*args, **kwargs)

	global SCORE1
	global NUMBERCORRECT
	SCORE1 = Maze.SCORE
	#SCORE1 = 0
	NUMBERCORRECT = 0

	self.multiselect = 0
	self.multimax = 1
	
	apple = Purchasable('apple.png', .50, 0)
	banana = Purchasable('banana.png', .49, 1)
	baseball = Purchasable('baseball.png', 1.25, 2)
	beachball = Purchasable('beachball.png', 3.99, 3)
	bike = Purchasable('bike.png', 109.99, 4)
	bread = Purchasable('bread.png', 4.99, 5)
	broom = Purchasable('broom.png', 7.50, 6)
	cake = Purchasable('cake.png', 6.00, 7)
	carrot = Purchasable('carrot.png', .60, 8)
	cheese = Purchasable('cheese.png', 1.99, 9)
	chicken = Purchasable('chicken.png', 12.01, 10)
	compass = Purchasable('compass.png', 5.50, 11)
	computer = Purchasable('computer.png', 279.99, 12)
	drum = Purchasable('drum.png', 399.99, 13)
	fan = Purchasable('fan.png', 5.00, 14)
	flower = Purchasable('flower.png', .25, 15)
	football = Purchasable('football.png', 8.50, 16)
	fryingPan = Purchasable('fryingpan.png', 9.49, 17)
	guitar = Purchasable('guitar.png', 149.00, 18)
	hamburger = Purchasable('hamburger.png', 1.00, 19)
	hammer = Purchasable('hammer.png', 2.25, 20)
	hotdog = Purchasable('hotdog.png', 1.00, 21)
	iceCream = Purchasable('icecream.png', 1.49, 22)
	jacket = Purchasable('jacket.png', 25.60, 23)
	lemon = Purchasable('lemon.png', .60, 24)
	lightbulb = Purchasable('lightbulb.png', .90, 25)
	microphone= Purchasable('microphone.png', 4.50, 26)
	microwave = Purchasable('microwave.png', 109.00, 27)
	parrot = Purchasable('parrot.png', 90.00, 28)
	pen = Purchasable('pen.png', 0.15, 29)
	pi = Purchasable('pi.png', 3.14, 30)
	piano = Purchasable('piano.png', 8199.99, 31)
	powersaw = Purchasable('powersaw.png', 129.99, 32)
	pumpkin = Purchasable('pumpkin.png', 6.00, 33)
	radio = Purchasable('radio.png', 23.49, 34)
	saxophone = Purchasable('saxophone.png', 190.00, 35)
	scissors = Purchasable('scissors.png', 2.99, 36)
	screwdriver = Purchasable('screwdriver.png', 2.99, 37)
	sneaker = Purchasable('sneaker.png', 24.50, 38)
	soccer = Purchasable('soccer.png', 18.99, 39)
	tShirt = Purchasable('tShirt.png', 12.50, 40)
	umbrella = Purchasable('umbrella.png', 7.49, 41)
	watermelon = Purchasable('watermelon.png', 5.00, 42)
	basketball = Purchasable('basketball.png', 15.50, 43)

	possibleItems = [apple, banana, baseball, basketball, beachball, bike, bread, broom, cake, carrot, cheese, chicken, compass, computer, drum, fan, flower, football, fryingPan, guitar, hamburger, hammer, hotdog, iceCream, jacket, lemon, lightbulb, microphone, microwave, parrot, pen, pi, piano, powersaw, pumpkin, radio, saxophone, scissors, screwdriver, sneaker, soccer, tShirt, umbrella, watermelon]
	
        self.camera = self.parent_camera.make_child(virtual_size = (WIDTH, HEIGHT))

        #Makes the shelf to place items on
        shelf_image = spyral.Image(filename='bookshelf.png')
        self.shelf = spyral.Sprite()
        self.shelf.image = shelf_image
	self.shelf.anchor = 'center'
        self.shelf.x = 300
        self.shelf.y = 450

        self.group = spyral.Group(self.camera)
        self.group.add(self.shelf)
	self.text = spyral.Group(self.camera)	
        
        topWidth = 75 #place the items on the shelf, selecting them randomly
        topHeight = 150
        self.items = []

        for i in range(0, 4):
            for j in range(0, 4):
		randitem = random.randint(0, len(possibleItems) - 1)
		item=Item(possibleItems[randitem].image, possibleItems[randitem].price, possibleItems[randitem].index, topWidth + i*125, topHeight + j*165)
                item.layer = 2
                self.items.append(item)
                self.group.add(item)

	count = 0
	font = spyral.Font(None, 32, (255, 255, 255)) #This is where the prices are placed on the itmes
	for i in range(0, 16):
	    itemprice = self.items[count].price
	    pricetext = '$' + str(Decimal(str(itemprice)).quantize(Decimal('.01')))
	    priceimage = spyral.Image(size=(100, 100))
	    priceimage = font.render(pricetext)
	    self.pricesprite =spyral.Sprite()
	    self.pricesprite.image = priceimage
	    self.pricesprite.layer = 3
	    self.pricesprite.x = self.items[count].x
	    self.pricesprite.y = self.items[count].y - 50
	    self.group.add(self.pricesprite)
	    count+=1	

        self.shoppingList = [] #This selects items to go in the shopping list
        for x in range (0, 4):
            itemNumber = random.randint(1, LEVEL + 2)
            itemListIndex = random.randint(0, len(self.items) - 1)
            item = self.items[itemListIndex]
            #This picks an item and the number of those items
            shoppingListItem = (item, itemNumber)
            self.shoppingList.append(shoppingListItem)
	
	#Discount Code:
            #We decided not to implement this due to the level of difficulty it created for the game player
            #The game as it stands is difficult to do mental math, and we worried that adding in percentages
            #would make the game too challenging and would frustrate the students
##	if LEVEL >= 1:
##		discountedItemNumber = random.randint(0,len(self.shoppingList)-1)
##		discounted = random.randrange(5, 90, 5)/100.
##		discount = (str(discounted)).quantize(Decimal('.01'))
##		self.shoppingList[discountedItemNumber][0].discount = discount

	for x in range (0, 5): #Place the dollar signs next to the textboxes
	    font = spyral.Font(None, 64, (255, 255, 255))
            dollarText = spyral.Image(size=(100, 100))
            dollarText = font.render('$')
            self.dollarTextSprite = spyral.Sprite()
            self.dollarTextSprite.image = dollarText
            self.dollarTextSprite.anchor = 'center'
            self.dollarTextSprite.x = 775
            self.dollarTextSprite.y = 250 + 100*x
            self.group.add(self.dollarTextSprite)	

        self.textBoxes = [] #Makes items and lists for textboxes
        shoppingListItem1 = self.shoppingList[0]
        shoppingListItem2 = self.shoppingList[1]
        shoppingListItem3 = self.shoppingList[2]
        shoppingListItem4 = self.shoppingList[3]
        
        #Textboxes are made here
        self.shoppingList1 = extras.TextBox(str(shoppingListItem1[1]) + ' ' + str(shoppingListItem1[0].name) + ': ',(900,250),shoppingListItem1[0].price*shoppingListItem1[1], (0,0,255))
        self.shoppingList2 = extras.TextBox(str(shoppingListItem2[1]) + ' ' + str(shoppingListItem2[0].name) + ': ',(900,350),shoppingListItem2[0].price*shoppingListItem2[1], (0,0,255))
        self.shoppingList3 = extras.TextBox(str(shoppingListItem3[1]) + ' ' + str(shoppingListItem3[0].name) + ': ',(900, 450),shoppingListItem3[0].price*shoppingListItem3[1], (0,0,255))
        self.shoppingList4 = extras.TextBox(str(shoppingListItem4[1]) + ' ' + str(shoppingListItem4[0].name) + ': ',(900,550),shoppingListItem4[0].price*shoppingListItem4[1], (0,0,255))
	self.type = shoppingListItem1[0].price*shoppingListItem1[1] + shoppingListItem2[0].price*shoppingListItem2[1] + shoppingListItem3[0].price*shoppingListItem3[1] + shoppingListItem4[0].price*shoppingListItem4[1]
        self.total = extras.TextBox("total: ",(900, 650), (shoppingListItem1[0].price*shoppingListItem1[1] + shoppingListItem2[0].price*shoppingListItem2[1] + shoppingListItem3[0].price*shoppingListItem3[1] + shoppingListItem4[0].price*shoppingListItem4[1]), (0,0,255))

        self.textBoxes.append(self.shoppingList1)
        self.textBoxes.append(self.shoppingList2)
        self.textBoxes.append(self.shoppingList3)
        self.textBoxes.append(self.shoppingList4)
        self.textBoxes.append(self.total)

        for box in self.textBoxes: #For each textbox give them descriptions, text, and a "button"
            self.text.add(box.description)
            self.text.add(box.btext)
            self.group.add(box.button)
            
        #Score
	font = spyral.Font(None, 64, (255, 255, 255))
        scoreText = spyral.Image(size=(100, 100))
        scoreText = font.render('Score: ' + unicode(SCORE1))
        self.scoreTextSprite = spyral.Sprite()
        self.scoreTextSprite.image = scoreText
        self.scoreTextSprite.anchor = 'center'
        self.scoreTextSprite.x = 900
        self.scoreTextSprite.y = 750
        self.group.add(self.scoreTextSprite)

    def check_click(self, position, group, select):
        local_position = self.camera.world_to_local(position)
        for sprite in group:
            sprite.deselect()
            if sprite.check_click(local_position):
                sprite.move(local_position)
                if(select == 1)and(self.multiselect < self.multimax):
                    sprite.select(self)
                    self.multiselect += 1
        self.multiselect = 0

    def deselect(self,List):
        for obj in List:
            if(obj.selected == 1):
                obj.deselect()

    def get_type(self,Text):
        if isinstance(Text, Decimal):
            return ""
        else:
            return Text.get_text()

    def set_type(self,text,Text):
        if isinstance(Text, Decimal):
            return ""
        else:
            return Text.set_text(text)

    def on_enter(self):
        background = spyral.Image(size=(WIDTH, HEIGHT))
        background.fill((0, 0, 0))
	shoppinglist = spyral.Image(filename='shopheading.png')
	background.draw_image(shoppinglist, position=(300, -325), anchor='center')
        self.camera.set_background(background)

    def render(self):
        self.group.draw()
	self.text.draw()

    def update(self, dt):
	global SCORE1
	global NUMBERCORRECT
        #self.group.update(dt)
        for event in self.event_handler.get():
            if event['type'] == 'QUIT':
                spyral.director.pop()
                return
            elif event['type'] == 'KEYDOWN':
		self.ntext = self.get_type(self.type) + event['ascii']
		self.set_type(self.ntext, self.type)
		#print self.type.dtext
                if event['ascii'] == 'q' or event['ascii'] == chr(27):
                    spyral.director.pop()
                    return
		elif event['ascii'] == chr(13):
                    if isinstance(self.type, Decimal):
                        pass
		    elif int(self.type.get_answer()) == 1:
			SCORE1+=200
			NUMBERCORRECT+=1
		    return
		elif event['ascii'] == chr(8):
		    txt = self.get_type(self.type)
		    txt = txt[:len(txt)-2]
		    self.set_type(txt,self.type)
		else:
		    return self.group.update(dt)
	    elif event['type'] == "MOUSEBUTTONDOWN":
                self.check_click(event['pos'], self.textBoxes,1)
            
            elif event['type'] == "MOUSEBUTTONUP":
                self.deselect(self.textBoxes)

	font = spyral.Font(None, 64, (255, 255, 255))
	scoreText = font.render('Score: ' + unicode(SCORE1))
        self.scoreTextSprite.image = scoreText
	if NUMBERCORRECT >= 5:
	    Maze.SCORE = SCORE1
	    spyral.director.pop()
