import spyral
import pygame
import Menu

WIDTH = 1200
HEIGHT = 900

class TextSprite(spyral.Sprite) :
    def __init__(self, image, x, y, *args, **kwargs):
        spyral.sprite.Sprite.__init__(self)
        self.image = image
        self.anchor = 'midleft'
        self.pos = (x, y)

class Correct(spyral.Scene):
    def __init__(self, *args, **kwargs):
        super(Correct, self).__init__(*args, **kwargs)
        self.camera = self.parent_camera.make_child(virtual_size = (WIDTH, HEIGHT))
        self.group = spyral.Group(self.camera)
        self.i = 0
    def on_enter(self):
        background = spyral.Image(size=(WIDTH,HEIGHT))
        background.fill((0,0,0))
        correct_image = spyral.Image(filename='Correct.jpg')
        background.draw_image(correct_image, position=(0,0), anchor='center')
        font = spyral.Font(None, 200, (255, 255, 255))
        text = spyral.Image(size=(100, 100))
        text = font.render('+' + unicode(500+(100*Menu.DIFFICULTY)) + '!')
        background.draw_image(text, position= (0,250), anchor='center')
        self.camera.set_background(background)
    def render(self):
        self.group.draw()
    def update(self, dt):
        """
        The update loop receives dt as a parameter, which is the amount
        of time which has passed since the last time update was called.
        """
        self.group.update(dt)
        if (self.i == 0):
            self.i = self.i + 1
        else:
            pygame.time.delay(2000)
            spyral.director.pop()
