#CISC374 Breakout Brittany Gradel, Justin Rutkowski, Matt Stagitis, Ian Watkins

import spyral
import random
import math

WIDTH = 1200
HEIGHT = 900

def collide_box(ball, box, pong):
    if ball.x < box.x + 50 and ball.x > box.x - 50 and ball.y < box.y + 10 and ball.y > box.y - 10:
        ball.vel_y = -ball.vel_y
        #box.image = spyral.Image (size=(80,20))
        pong.boxes.remove(box)

class Box(spyral.Sprite) :
    def __init__(self, x, y, *args, **kwargs):
        ##super(box, self).__init__(*args, **kwargs)
        spyral.sprite.Sprite.__init__(self)
##        self.width = 20
##        self.height = 20
##        self.camera = self.parent_camera.make_child(virtual_size = (WIDTH, HEIGHT))
        self.image = spyral.Image(size=(80, 20))
        #self.image.fill((255, 255, 0))
##
##        self.anchor = 'center'
##
        self.pos = (x, y)

##        def deleteBox(self):
##            self.image = spyral.Image(size=(0,0))

##        def collide_box(ball, self):
##            if ball.get_rect().collide_rect(self.get_rect()):
##                ball.vel_y = -ball.vel_y

class Ball(spyral.Sprite):
    def __init__(self, scene):
        super(Ball, self).__init__()
        # We take the scene as an argument so that we can have the ball
        # Tell the screen when the ball has hit an edge, so that a new
        # ball can be created.
        self.scene = scene
        
        self.image = spyral.Image(size=(20, 20))
        self.image.draw_circle((255, 255, 255), (10, 10), 10)
        
        # We'll start by picking a random angle for the ball to move
        # We repick the direction if it isn't headed for the left
        # or the right hand side
        theta = random.random()*2*math.pi
        while (theta < math.pi/4 and theta > 3*math.pi/4):
            theta = random.random()*2*math.pi
        # In addition to an angle, we need a velocity. Let's have the
        # ball move at 300 pixels per second
        r = 300
        
        self.vel_x = r * math.cos(theta)
        self.vel_y = r * math.sin(theta)
        
        # We'll use the center of the ball for the anchor
        self.anchor = 'center'
        # We'll start the ball at the center. self.pos is actually the
        # Same as accessing sprite.x and sprite.y individually
        self.pos = (WIDTH/2, HEIGHT-150)
                
    def update(self, dt):
        self.x += dt * self.vel_x
        self.y += dt * self.vel_y
        lost = False
        
        # We use the rect for checking collisions
        # This saves having to take into account the anchor and the
        # size of sprite, as it is accounted for in the rect.
        r = self.get_rect()
        if r.top < 0:
            # We'll change this rect a bit, and use it to set the x and y coordinates again
            r.top = 0
            self.vel_y = -self.vel_y
##        if r.bottom > HEIGHT and lost == False:
####            r.bottom = HEIGHT
####            self.vel_y = -self.vel_y
##            print "Sorry you lost"
##            lost = True
        if r.right < 0:
            r.right = 0
            self.vel_x = -self.vel_x
        if r.left > WIDTH:
            r.left = WIDTH
            self.vel_x = -self.vel_x
        
        self.pos = r.center # We reset the pos using the cnter of the rect, since we are anchored

    def collide_paddle(self, paddle):
        if self.get_rect().collide_rect(paddle.get_rect()):
            self.vel_y = -self.vel_y
##    def collide_box(self, box):
##        if self.get_rect().collide_rect(box.get_rect()):
##            self.vel_y = -self.vel_y
##            #box.image = spyral.Image(size=(0,0))
            
            

class Pong(spyral.Scene):
    def __init__(self, *args, **kwargs):
        super(Pong, self).__init__(*args, **kwargs)
        
        self.camera = self.parent_camera.make_child(virtual_size = (WIDTH, HEIGHT))
        
        paddle_image = spyral.Image(size=(300, 20))
        paddle_image.fill((255, 255, 255))
        paddle_image2 = spyral.Image(size=(0, 0))
        paddle_image2.fill((255, 255, 255))

##        box_image = spyral.Image(size=(20, 20))
##        box_image.fill((255, 255, 255))

        
        # We want to make sure we keep the paddles around, since we'll
        # work with them for motion and collision detection
        self.left_paddle = spyral.Sprite()
        self.left_paddle.image = paddle_image2
        # This anchor means that the x and y coordinates we assign are
        # relative to the middle left of the image.
        self.left_paddle.anchor = 'midleft'
        # We'll keep the paddle just slightly off of the wall
        self.left_paddle.x = 20
        # We'll have the paddle start out vertically centered
        self.left_paddle.y = HEIGHT/2
        
        self.right_paddle = spyral.Sprite()
        self.right_paddle.image = paddle_image
        self.right_paddle.anchor = 'midright'
        self.right_paddle.x = WIDTH/2
        self.right_paddle.y = HEIGHT - 100
        
        self.ball = Ball(self)

        boxcount = 10
        topWidth = 100
        topHeight = 100
        self.boxes = []

        self.group = spyral.Group(self.camera)

        for i in range(0, boxcount):
            for j in range(0, boxcount):
                box=Box(topWidth + i*100, topHeight + j*50)
                self.boxes.append(box)
                self.group.add(box)
        


##        self.box = spyral.Sprite()
##        self.box.image = box_image
##        self.box.anchor = 'center'
##        self.box.x = 20
##        self.box.y = 20
        
##        box = {}
##        for x in range(0, 20):
##            for y in range(0, 20):
##                box[[x, y]] = spyral.Image(size = (20,20))
##                box[{x, y}].fill((255, 255, 255))
        
        # We have to give our camera to the group so it knows where to draw

        # We can add the sprites to the group
        self.group.add(self.right_paddle, self.ball)
        
        # We should track whether the paddles are moving up and down
        self.left_paddle.moving = False
        self.right_paddle.moving = False
        
    def score(self, side):
        pass    
        
    def on_enter(self):
        background = spyral.Image(size=(WIDTH,HEIGHT))
        background.fill((0,0,0))
        self.camera.set_background(background)
        
    def render(self):
        # Simply tell the group to draw
        self.group.draw()
        
    def update(self, dt):
        """
        The update loop receives dt as a parameter, which is the amount
        of time which has passed since the last time update was called.
        """
        self.group.update(dt)
        
        # Gets all the events from the event handler
        for event in self.event_handler.get():
            # You should always be sure you're handling the quit events
            if event['type'] == 'QUIT':
                spyral.director.pop()  # Happens when someone asks the OS to close the program
                return
            if event['type'] == 'KEYDOWN':
                # On keydown, we store the direction the paddle should be moving
                # We reset this on keyup, so that holding down the buttons works
                #if event['ascii'] == 'w':
                #    self.left_paddle.moving = 'up'
                #if event['ascii'] == 's':
                #    self.left_paddle.moving = 'down'
                if event['ascii'] == 'q':
                    spyral.director.pop()  # Happens when someone asks the OS to close the program
                    return
                if event['key'] == spyral.keys.left:
                    self.right_paddle.moving = 'left'
                if event['key'] == spyral.keys.right:
                    self.right_paddle.moving = 'right'
            elif event['type'] == 'KEYUP':
                if event['ascii'] in ('w', 's'):
                    self.left_paddle.moving = False
                if event['key'] in (spyral.keys.left, spyral.keys.right):
                    self.right_paddle.moving = False
        
        paddle_velocity = 250
        
        # Since we don't want to repeat code for the left and the right
        # paddles, which should behave the same, we make a function
        def move_and_correct(paddle):
            # Move the paddle if it should be moving
            if paddle.moving == 'left':
                paddle.x -= paddle_velocity * dt
            elif paddle.moving == 'right':
                paddle.x += paddle_velocity * dt
                
            # We'll do some collision detection with the top and bottom
            # Just like we did for the ball
            r = paddle.get_rect()
            if r.top < 0:
                r.top = 0
            if r.bottom > HEIGHT:
                r.bottom = HEIGHT
            
            # We set the position based on the rect, but we use each sprite's
            # anchor for setting the coordinates since they are different
            paddle.pos == getattr(r, paddle.anchor)
        
        move_and_correct(self.left_paddle)
        move_and_correct(self.right_paddle)
        
        
        self.ball.collide_paddle(self.left_paddle)
        ##self.ball.collide_box(self.box)
        self.ball.collide_paddle(self.right_paddle)
        for box in self.boxes:
            #self.ball.collide_box(box)
            collide_box(self.ball, box, self)
        
        
