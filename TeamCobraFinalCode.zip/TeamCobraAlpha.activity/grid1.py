import pygame




 
# Define some colors
black    = (   0,   0,   0)
white    = ( 255, 255, 255)
green    = (   0, 255,   0)
red      = ( 255,   0,   0)
 
# This sets the width and height of each grid location
width=20
height=20
 
# This sets the margin between each cell
margin=5
 
grid=[]
for row in range(10):
    grid.append([])
    for column in range(10):
        grid[row].append(0) # Append a cell
 
grid[1][5] = 1
grid[1][6] = 1
grid[1][7] = 1
grid [1][8] = 1

grid[3][2] = 1
grid[3][3] = 1
grid[3][4] = 1
grid[3][5] = 1
grid[3][6] = 1

grid[3][8] = 1
grid[4][8] = 1



 
pygame.init()
  
size=[255,255]
screen=pygame.display.set_mode(size)
 
pygame.display.set_caption("Battleship")
 
done=False
 
clock=pygame.time.Clock()
 
while done==False:
    for event in pygame.event.get(): 
        if event.type == pygame.QUIT: 
            done=True
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = pygame.mouse.get_pos()
            column=pos[0] // (width+margin)
            row=pos[1] // (height+margin)
            grid[row][column] = 2
       
        
 
    screen.fill(black)
 
    for row in range(10):
        for column in range(10):
            color = white
            if grid[row][column] == 1:
                color = green
            pygame.draw.rect(screen,color,[(margin+width)*column+margin,(margin+height)*row+margin,width,height])

            if grid[row][column] == 2:
                color = red
            pygame.draw.rect(screen,color,[(margin+width)*column+margin,(margin+height)*row+margin,width,height])

            if grid[row][column] == 3:
                color = blue
            pygame.draw.rect(screen,color,[(margin+width)*column+margin,(margin+height)*row+margin,width,height])
     
    clock.tick(20)
 
    pygame.display.flip()
     
pygame.quit ()
