import spyral
import pong

def main():
    spyral.director.push(pong.Pong())